module.exports = Self => {
    Self.remoteMethodCtx('executeRoutine', {
        description: 'Return the routes by worker',
        accessType: '*',
        accepts: [
            {
                arg: 'routine',
                type: 'string',
                description: 'The routine sql',
                required: true,
                http: {
                    source: 'path'
                }
            },
            {
                arg: 'params',
                type: ['any'],
                description: 'The array of params',
                required: true,
            }
        ],
        returns: {
            type: 'any',
            root: true
        },
        http: {
            path: `/:routine/execute-routine`,
            verb: 'POST'
        }
    });
    Self.executeRoutine = async(ctx, routine, params, options) => {
        const models = Self.app.models;
        const myOptions = {};
        if (typeof options == 'object')
            Object.assign(myOptions, options);
        const checkACL = await models.ACL.checkAccessAcl(ctx, 'Application', routine, '*');
        if (!checkACL) throw error;
        const requestParams = [routine];
        requestParams.concat(params);

        return Self.app.models.Route.rawSql(`CALL ?(...)`, requestParams, myOptions);
    };
};
